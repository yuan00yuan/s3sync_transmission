from __future__ import print_function
from datetime import datetime, timedelta
from time import sleep


import boto3
import botocore
import base64
import os
print('Loading function')
#Build Queue at first
#get monitoring period of cloudwatch 
cloud_watch= boto3.client('cloudwatch')
client=boto3.client('ecs')
def lambda_handler(event, context):
    end_time = datetime.now()
    start_time = datetime.now() - timedelta(seconds=300)
    print("Get average size of queue from %s to %s"%(start_time,end_time))
	queuename = os.environ['queueName']
	myservices= os.environ['myservices']
	mycluster = os.environ['mycluster']
    response = cloud_watch.get_metric_statistics(
        Namespace='AWS/SQS',
        MetricName='ApproximateNumberOfMessagesVisible',
        Dimensions=[
            {
                'Name': 'QueueName',
                'Value': queuename
            },
        ],
        StartTime=start_time,
        EndTime=end_time,
        Period=300,
        Statistics=['Average'],
        Unit= 'Count'
    )
    try:
        metric_size = int(response['Datapoints'][0]['Average'])
        print('queue')
        print(metric_size)
        request_task(capacity=10)
    except IndexError:
        metric_size = 0
    print('Queue size in Cloudwatch Metric Value is %d'%metric_size)
	
    
def request_task(capacity):
    print("changing tasks")
    response = client.update_service(
		desiredCount=capacity,
		service=myservices,
		cluster=mycluster, 
		)
def delete_task( ):
    print("changing tasks")
    response = client.update_service(
		desiredCount=1,
		service='md-MyServices-4CGMOM3UJHNN',
		)
