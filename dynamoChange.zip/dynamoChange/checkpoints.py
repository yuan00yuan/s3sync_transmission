import boto3
import botocore

class CheckPoints:
    def __init__(self, upload_id, profile=None,table_name="Transport_Parts", count_table='Transport_Counter'):
        """Save the completed parts 
    :param upload_id: Multi-part uploadId from S3 destination 
    :param table_name: The table which saves the completed parts list, contains ETag and partNumber
    :param count_table: The table which saves the number of completed parts and the number of parts need to upload
    """
        if profile is None:
            self.client = boto3.client('dynamodb')
        else:
            session = boto3.Session(profile_name = profile)
            self.client = session.client('dynamodb')
        try:
            self.client.describe_table(TableName=table_name)
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code']== "ResourceNotFoundException":
                self.client.create_table(
                 TableName=table_name,
                 AttributeDefinitions=[
                   {
                        'AttributeName':'uploadId',
                        'AttributeType':'S'
                    },
                   {
                        'AttributeName':'partNumber',
                        'AttributeType':'N'
                    }
                ],
                 KeySchema=[
                    {
                        'AttributeName':'uploadId',
                        'KeyType':'HASH'
                     },
                    {
                        'AttributeName':'partNumber',
                        'KeyType':'RANGE'
                     }
                ],
                 ProvisionedThroughput={
                    "ReadCapacityUnits": 5,
                    "WriteCapacityUnits": 5
                }                            
            )
        try:
            self.client.describe_table(TableName=count_table)
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code']== "ResourceNotFoundException":
                self.client.create_table(
                     TableName=count_table,
                     AttributeDefinitions=[
                       {
                            'AttributeName':'uploadId',
                            'AttributeType':'S'
                        }
                    ],
                     KeySchema=[
                        {
                            'AttributeName':'uploadId',
                            'KeyType':'HASH'
                         }
                    ],
                     ProvisionedThroughput={
                        "ReadCapacityUnits": 5,
                        "WriteCapacityUnits": 5
                    }                            
                )
        self.table=table_name
        self.count_table=count_table
        self.partition=upload_id
        
    def create(self,task_count,s3_bucket,key_name):
        #Create the upload number of total upload tasks in DynamoDB
        if type(task_count) is int:
            _task_count = dict(N=str(task_count))
        else:
            _task_count = dict(N=task_count)
        self.client.put_item(
            TableName=self.count_table,
            Item={"uploadId":{"S":self.partition},
                    "bucket":{"S":s3_bucket},
                    "keyName":{"S":key_name},
                    "taskCount":_task_count,
                    "completed":{"N":"0"}
                  }         
        )
        
                
    
    def check(self,part_number,etag,range):
        """ After completing the part upload, insert etag and partNumber into DynamoDB
        """
        if type(part_number) is int:
            _part_num = dict(N=str(part_number))
        else:
            _part_num = dict(N=part_number)
        self.client.put_item(
            TableName=self.table,
            Item={"uploadId":{"S":self.partition},"partNumber":_part_num,"eTag":{"S":etag},"range":{"S":range}}
        )
        self.client.update_item(
            TableName=self.count_table,
            Key={"uploadId":{"S":self.partition}},
            UpdateExpression='set completed = completed + :num',
            ExpressionAttributeValues = {":num":{"N":"1"}}
        )
        
        
    def get_checkpoints(self):
        checkpoints=[]
        response = self.client.scan(                 
            TableName = self.table,
            ExpressionAttributeValues={
                    ':a': {
                        'S': self.partition,
                    },
            },
            FilterExpression='uploadId = :a',
            )
        nums_temp=[]
        for item in response['Items']:
        #updated
            int part_num_temp = int(item['partNumber']['N'])
            if part_num_temp not in nums_temp:
                nums_temp.append(int(item['partNumber']['N']))
                checkpoints.append(dict(ETag=item['eTag']['S'], PartNumber=int(item['partNumber']['N'])))

        checkpointsnew=[]
        checkpointsnew = sorted(checkpoints, key=lambda k: k['PartNumber'])
        return checkpointsnew
            
         
        