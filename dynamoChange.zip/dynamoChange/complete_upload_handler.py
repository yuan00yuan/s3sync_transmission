from __future__ import print_function

from dynamoChange.s3_utils import UploadHandler
from dynamoChange.checkpoints import CheckPoints

import configparser
import boto3
import os

def lambda_handler(event, context):
    print('Loading function')
    config= configparser.ConfigParser()
    config.read("dynamoChange/config.cfg")
    
    accessKey = os.environ['accessKey']
    accessSecret = os.environ['accessSecret']
    region = os.environ['region']
    
    counterTable = os.environ['counterTable']
    partTable = os.environ['partTable']

    ec2_client = boto3.client('ec2')
    s3 = boto3.client('s3',
                  region_name = region,
                  aws_access_key_id = accessKey,
                  aws_secret_access_key = accessSecret
    )
    for record in event['Records']:
        try:
            if record['eventName'] != "MODIFY":
                continue
            print("get modify record as:%s"%record['dynamodb'])
            data = record['dynamodb']['NewImage']
            if int(data['completed']['N']) >=int(data['taskCount']['N']):
                uploader = UploadHandler(bucket = data['bucket']['S'],
                                         key = data['keyName']['S'],
                                         client = s3,
                                         uploadId = data['uploadId']['S'])
                check_points = CheckPoints(upload_id =data['uploadId']['S'],
                                         table_name = partTable,
                                         count_table = counterTable)
                check=check_points.get_checkpoints()
                uploader.complete_upload(check)
        except KeyError:
            continue
    return 'Successfully processed {} records.'.format(len(event['Records']))