import boto3
from s3put.s3_utils import UploadHandler
from s3put.s3_utils import DownloadHandler
from s3put.sqs_utils import SQSQueue
from time import sleep
from s3put.checkpoints import CheckPoints
import configparser
import logging
import json
import os

class S3Task:
    def __init__(self,src_bucket,dest_bucket,key_name,range,upload_id,part_number,target_client):
        """Initialize the parameters
        """
        self.src_bucket=src_bucket
        self.dest_bucket=dest_bucket
        self.key_name=key_name
        self.range=range
        self.upload_id=upload_id
        self.part_number=part_number
        self.target_client=target_client
    
    def execute(self):
        """Download the range bytes from source bucket, and upload the bytes to the destination directly
            After the transferring, need to save the returned Etag and related information into DynamoDB
        """
        downloader = DownloadHandler(bucket = self.src_bucket, key = self.key_name)
        uploader = UploadHandler(bucket = self.dest_bucket,key = self.key_name,uploadId = self.upload_id, client = self.target_client)
        down_resp = downloader.download_range(self.range)
        part_dict = uploader.upload_part(down_resp.get("Body").read(),self.part_number)
        check_points = CheckPoints(self.upload_id)
        check_points.check(self.part_number,part_dict['ETag'],self.range)
        
if __name__ == "__main__":
    config= configparser.ConfigParser()
    config.read("config.cfg")
    task_queue = os.environ['queueName']
    dest_bucket = os.environ['bucket']
    accessKey = os.environ['accessKey']
    accessSecret = os.environ['accessSecret']
    region = os.environ['region']
    
    target_client = boto3.client('s3',
          region_name = region,
          aws_access_key_id = accessKey,
          aws_secret_access_key = accessSecret
          )
    
    logging.basicConfig(level=logging.DEBUG,  
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',  
                    datefmt='%a, %d %b %Y %H:%M:%S',  
                    filename='task.log',  
                    filemode='w')  
    while True:
        try:
            message_str = task_queue.get_message()
            if message_str is None:
                sleep(5)
                continue
            logging.info("Got task message as %s"%message_str)
            message = json.loads(message_str)
            if message.get('upload_id',None) is None:
			"""
			   ?????uploadId???????????????????????---???task
			"""
                downloader = DownloadHandler(bucket = message['src_bucket'], key = message['key_name'])
                down_resp = downloader.download()
                uploader = UploadHandler(bucket = message['dest_bucket'],key = message['key_name'],client = target_client)
                uploader.put_object(down_resp.get("Body").read())
            else:
			"""
			    ????uploadid???????? ----????task
			"""
                message.update({"target_client":target_client})  //????target????client
                task = S3Task(**message)  //????s3task??
                task.execute()            //???execute
            task_queue.delete_message()   //?????????��????
        except Exception as err:
                logging.exception("Get Error %s"%err)
                continue   
