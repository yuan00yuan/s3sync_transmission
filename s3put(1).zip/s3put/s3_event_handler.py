
from __future__ import print_function
from s3put.sqs_utils import SQSQueue
from s3put.s3_utils import calculate_range_parameter
from s3put.s3_utils import UploadHandler, DownloadHandler
from s3put.checkpoints import CheckPoints
from importlib import reload
from urllib.parse import unquote_plus

import configparser
import json
import urllib
import boto3
import os

import sys
reload(sys)


def lambda_handler(event, context):
    config= configparser.ConfigParser()
    config.read("s3put/config.cfg")
    print('Loading function');
    task_queueName = os.environ['queueName']
    task_queue = SQSQueue(None,queue_name = task_queueName)
    minSize = config.get("trans","minSize")
    if minSize is None:
        min_size = 8*1024*1024
    else:
        min_size = int(minSize)*10
    chunkSize = config.get("trans","chunkSize")
    if chunkSize is None:
        part_size = 100*1024*1024
    else:
        part_size = 7043428
    dest_bucket = os.environ['bucket']
    accessKey = os.environ['accessKey']
    accessSecret = os.environ['accessSecret']
    region = os.environ['region']
    #build target s3 client for uploading
    s3 = boto3.client('s3',
                  region_name = region,
                  aws_access_key_id = accessKey,
                  aws_secret_access_key = accessSecret
   )
    #build ec2 client  in current region by lambda execution role
    ec2_clienat = boto3.client('ec2')

    counterTable = os.environ['counterTable']
    partTable = os.environ['partTable']
    try:
        for record in event['Records']:
            src_bucket = record['s3']['bucket']['name']
            parser=urllib.parse
            key_name=record['s3']['object']['key']
            key_name = unquote_plus(key_name)
            total_size = record['s3']['object']['size']
            if total_size <= 0:
                continue
            '''elif total_size < min_size:
                print("transfer file directly")
                downloader = DownloadHandler(bucket = src_bucket, key = key_name)
                down_resp = downloader.download()
                print('upload done')
                uploader = UploadHandler(bucket = dest_bucket,key = key_name,client = s3)
                uploader.put_object(down_resp.get("Body").read())
                                                '''
            if total_size < part_size:
                print("transfer file as single task")
                task_queue.send_message(json.dumps({'dest_bucket':dest_bucket,
                                                             'src_bucket':src_bucket,
                                                             'key_name':key_name}, ensure_ascii=False))
            else:
                print("transfer file as multiple task")
                parts = total_size//part_size + 1
                #initialize the multipart upload
                uploader = UploadHandler(bucket = dest_bucket,
                                         key = key_name,
                                         client = s3)
                uploadId = uploader.create_multipart_upload()
                """insert basic information of task as information
                """
                check_points=CheckPoints(upload_id = uploadId,
                                         table_name = partTable,
                                         count_table = counterTable)
                check_points.create(parts, dest_bucket,key_name)
                for part_number in range(0,parts):
                    range_size =  calculate_range_parameter(part_size,part_number,parts,total_size)
                    task_queue.send_message(json.dumps({'dest_bucket':dest_bucket,
                                                             'src_bucket':src_bucket,
                                                             'key_name':key_name,
                                                             'range':range_size,
                                                             'upload_id':uploadId,
                                                             'part_number':part_number+1}, ensure_ascii=False))
                    print('end')
    except Exception as err:
            print("Get Error %s"%err) 
            raise err